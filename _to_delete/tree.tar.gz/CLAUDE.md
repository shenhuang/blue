Each edit in this project should be completed with scalability and maintainability in mind.

A new session should be able to pick up from previous sessions, ensuring new edits can take into account anything related across the entire codebase.

When the context is about to be get too large that can cause brain rot, the user will be warned.

When suggesting new prompts, also suggests the appropriate model and effort level.

Always try to make correct suggestions rather than agree to what's wrong.

Before start, always try to make sure everything needed is clearly discussed, never start with assumptions.

If appropriate, try to parallel tasks to be more efficient. Or suggest parallelization plan if not doable alone.

想长期守住的解耦 / 约定，尽量落成**机制**（regress 门、脚本、gitignore、类型、目录边界），而不是散文——散文随 session churn 丢失，机制不会。每加一条约定先问：「它能不能变成一个会在 `npm run regress` 里失败的检查？」能就那样做（例：`engine ↛ ui` 由 `check-boundaries` 强制·见 quirk #95；定位由 `npm run handoff` 再生·见 quirk #96）。

## 文档维护约定（避免 STATUS 膨胀）
- 新 session 的进度按日期追加到 `docs/archive/CHANGELOG.md`，不要堆进 `STATUS.md` 头部 blockquote。
- 持久的 gotcha/约定写进 `docs/QUIRKS.md`（编号只增不重排，别处引用 "quirk #N"）。
- `STATUS.md` 只保留"当前状态"参考 + 最近 ~2 个 session；更早的滚动归档进 CHANGELOG。
- SPEC 文档在 `docs/spec/`，历史报告在 `docs/archive/`。
- `docs/NEXT_SESSION_PROMPT.md` 是**本地 session 交接文件**·已 gitignore·每个 session 重写·**不提交、不发布**（只读磁盘版本接力·别 `git add` 它）。

## 起手约定（轻起手·省上下文·避免 brain rot）
- **定位用 `npm run handoff` 从 git 再生**（`git log`+`status`+最新 nightly REPORT 头+STATUS 顶 blockquote+CHANGELOG 尾·纯只读·不留锁）——别手抄「做了什么」，交接 prompt 只留人写的方向/下一步（quirk #96）。
- **开局只"定位"，"验证"留到 ship 前**：起手用 `git log -3` + `git status` + 瞥最新 `docs/archive/nightly/REPORT-*` 确认基线绿即可；**不在起手跑全量 regress**（昨晚 nightly 已验证全绿并提交·起点几乎必绿）。要便宜体检就 `npm run regress:quick`（只 typecheck）。
- **SPEC 按方向懒加载**：`docs/spec/` 是参考资料·按本 session 选定方向只读相关那条·别开局全读（~570 行全灌会撑爆上下文）。
- **全量 `npm run regress` 是 ship 前的门、不是起手仪式**：迭代跑子集 `--only typecheck,<子系统>`；提交/发布前才跑一次全绿。夜间发布与周末引擎收尾仍各自跑全绿——无人值守 + 上生产那一环不减负。

## 并发隔离（方案 A·已实装 2026-06-10·quirk #104）
- **交互 session 在 `main`；周末内容引擎 commit 只落 `auto/weekend` 分支（不碰 main·不 push）；夜间任务 verify 绿后把 `auto/weekend` ff 收进 main 再发布。** `npm run handoff` 会显示当前分支 + auto/weekend 待合并数。
- 沙箱 checkout 只能「加/改」不能「删」（mount 不能 unlink）：main→auto/weekend 方向随时可切；**含新增文件的分支切回 main 会被挡**——周末档收尾停在 auto/weekend 是正常态，夜间 ff（`git branch -f main auto/weekend`·移 ref 不动树）后自然回 main；急用 main 由作者本机 `git checkout main`。
- 树停在 auto/weekend 时交互 session 别把自己的改动 commit 进该分支——等合并或让作者切回。
- **多 feature 并行用 `git worktree`（不切主树·绕开上面的 unlink 坑）**：主线留 `main`，第二条线 `git worktree add ../Blue-<t> -b feat/<t>` 开独立目录+分支，各自 `npm install`/`npm run regress`/commit，绿了回 main 树 `git merge` 再 `git worktree remove`。`npm run handoff` 会列出 >1 棵 worktree。**append-only 文档（CHANGELOG/QUIRKS）只在 main 整合时写、别在 feature 树里碰**＝免冲突。细节见 quirk #130。

## 存档约定（未发布·不迁移·quirk #99）
- 游戏未发布：**做改动别考虑存档兼容、别为兼容加复杂度**。存档只做版本相等校验——版本不符 / 损坏 → 启动即删旧档、从头开始（`engine/state.ts`·已删 `migrateSave` 迁移链）。
- 纯加字段不必 bump `SAVE_VERSION`（`createNewRun` 种默认 + `?? 默认` 兜底）；**改坏 / 重构形状想废旧档就 bump，别写迁移代码**。

## 并行 session 编排（方案 C·psm·已实装 2026-06-20·见 docs/infra/parallel-sessions.md）
- **多 session 并行＝每条一棵 worktree + 一条车道**，别再手动 `git worktree`（quirk #130 那串收进了一条命令）。开线：`node scripts/psm.mjs start <name> --lane <glob,...>`（自动 worktree+相对指针+symlink node_modules+登记台账·起手自检车道重叠）。`npm run psm -- status` / `node scripts/psm.mjs status` 看在飞的。
- **如果你是被开在某条 session worktree 里的**：只动**自己车道内**的文件——越界 `git commit` 会被 pre-commit 车道门**警告并停下**（真要越界：`PSM_CONFIRM=1 git commit`，或重划车道）。append-only 文档（CHANGELOG/QUIRKS）别在 feature 树碰·合并后在 main 追加。
- **收工**：`node scripts/psm.mjs land <name>` → 自动 rebase 最新 main + 跑绿门，**绿了停下等人确认**·不自动合。确认后在 **main 树**跑 `psm land <name> --yes`（或 `psm merge <name>`）做 ff 合并；staleness + 串行锁保证两条线先后合时第二条 rebase 重测。
- **绿门是 affected 选测**（不再每次全测·`gate.affected`）：按改动文件沿依赖图只跑受影响的 playthrough（`scripts/affected-tests.mjs`·健全回退 ALL）。Mac 实跑受影响行为测；沙箱无 esbuild 则跑静态门 + 精确报告「Mac 上补跑这些」。`psm land --full` 强制全量。细节见 docs/infra/parallel-sessions.md。
- **清理**：合完 worktree 留在原地（沙箱不能 unlink·quirk #1），**Mac 本机** `node scripts/psm.mjs gc` 收。**别手动 `git worktree remove`/`prune`**（相对指针·quirk #138·prune 还会误删 weekend worktree）。
