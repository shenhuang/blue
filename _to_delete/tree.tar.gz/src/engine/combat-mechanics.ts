// 特殊敌人机制钩子（战斗系统 SPEC §7 一族·数据驱动）
//
// 自包含钩子，全部由 EnemyDef 数据字段驱动（phases / headEnrage / environmentalPressure /
// splitBehavior / corpseEating / metamorphosis / maternalBehavior / swarmRelocate / selfDestruct /
// warrenPheromones+warrenReinforce+warrenFeed+warrenScreen＝The Warren 女王身体库存主线 §15）：不带对应
// 字段的普通敌人在每个钩子里都是 no-op ⇒ 普通战斗逐字节不变。形状统一 GameState→GameState
// （maybeInterceptJuvenile 例外：返回 GameState|null，供 applyAttack 在截击命中时短路返回）。
//
// 共享工具（getEnemyDef / setCombat / pushCombatLog / applyStatsDelta / randRange / rollChance）
// 留在 combat.ts 导出（主流程与钩子两边共用）——combat ↔ combat-mechanics 互为静态 import，
// 但两边模块顶层互不调用（只在运行时进函数体），ESM 循环加载安全。

import type { GameState, EnemyInstance, EnemyDef, BossPhase, InventoryItem } from '@/types';
import { addToInventory, enqueuePickup } from './state';
import { frontmostLivingSegment } from './chain-eel';
import {
  getEnemyDef,
  setCombat,
  pushCombatLog,
  applyStatsDelta,
  randRange,
  rollChance,
} from './combat';

// ——— Boss 阶段系统 ———

/**
 * maybeBossPhaseShift：HP 变化后检查是否进入新 boss 阶段。
 *
 * 规则：phases 以 hpThreshold 降序排列（[0.6, 0.3, 0.1]）。
 * "最高已触发阶段" = 数组里满足 phase.hpThreshold >= currentHpRatio 的最大 index。
 * 若比 bossPhaseIndices 记录的更高，则视为进入新阶段：
 *   - 推 transitionText 进 log
 *   - 若有 stanceForce → 更新 instance.stance
 *   - 若有 attacksOverride / aiPatternOverride → 写入 instance.phaseAttacksOverride / phaseAiPattern
 */
export function maybeBossPhaseShift(state: GameState, instanceId: string): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;
  const instance = combat.enemies.find((e) => e.instanceId === instanceId);
  if (!instance || instance.hp <= 0) return state;
  const def = getEnemyDef(instance.defId);
  if (!def?.phases?.length) return state;

  const currentHpRatio = instance.hp / def.hp;
  // 找满足 hpThreshold >= currentHpRatio 的最大 index（phases 降序·越大 index = 越深触发）
  let highestTriggeredIndex = -1;
  for (let i = 0; i < def.phases.length; i++) {
    if (def.phases[i].hpThreshold >= currentHpRatio) {
      highestTriggeredIndex = i;
    }
  }

  const currentIndex = combat.bossPhaseIndices?.[instanceId] ?? -1;
  if (highestTriggeredIndex <= currentIndex) return state; // 无新阶段

  const newPhase = def.phases[highestTriggeredIndex] as BossPhase;

  // 更新阶段索引
  let s = setCombat(state, (c) => ({
    ...c,
    bossPhaseIndices: { ...(c.bossPhaseIndices ?? {}), [instanceId]: highestTriggeredIndex },
  }));

  // 过渡叙事
  s = pushCombatLog(s, { actor: 'system', text: newPhase.transitionText });

  // 写入实例覆盖（stance / attacksOverride / aiPatternOverride）
  s = setCombat(s, (c) => ({
    ...c,
    enemies: c.enemies.map((e) => {
      if (e.instanceId !== instanceId) return e;
      return {
        ...e,
        ...(newPhase.stanceForce ? { stance: newPhase.stanceForce } : {}),
        ...(newPhase.attacksOverride ? { phaseAttacksOverride: newPhase.attacksOverride } : {}),
        ...(newPhase.aiPatternOverride ? { phaseAiPattern: newPhase.aiPatternOverride } : {}),
      };
    }),
  }));

  return s;
}

/**
 * maybeChainEelEnrage：链鳗（分节实体）头节 enrage —— **party-state 触发**（≠ HP 阈值）。
 *
 * 触发：在 attackInOrder 遭遇里，**最前存活节**（lowest-index living）带 def.headEnrage 且尚未 enrage 时，
 * 视为「头节被逼到最前」（前置体节全死）→ 推 transitionText 进 log、按 headEnrage 写实例覆盖
 * （stance / phaseAttacksOverride / phaseAiPattern·复用 BossPhase 的写法）。
 * 幂等：链鳗里只有本函数把 stance 设 'enraged'，故已 enraged ⇒ 跳过（不重复推文本）。
 *
 * 与 maybeBossPhaseShift（HP 路径·#149/#159）**完全独立**——不改其分发，只共用 stance/attacks 写法套在新触发上。
 * 非 attackInOrder 遭遇 / 最前节无 headEnrage（是体节）→ 直接返回（普通战斗逐字节不变）。
 */
export function maybeChainEelEnrage(state: GameState): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;
  if (!combat.attackInOrder) return state;
  const front = frontmostLivingSegment(combat.enemies);
  if (!front || front.stance === 'enraged') return state; // 无存活节 / 已 enrage（幂等）
  const def = getEnemyDef(front.defId);
  const enr = def?.headEnrage;
  if (!enr) return state; // 当前最前节是体节（无 headEnrage）→ 不动

  // 过渡叙事（[待过稿]·#117）
  let s = pushCombatLog(state, { actor: 'system', text: enr.transitionText });
  // 写实例覆盖（复用 BossPhase 写法·触发改为 party-state）
  s = setCombat(s, (c) => ({
    ...c,
    enemies: c.enemies.map((e) =>
      e.instanceId === front.instanceId
        ? {
            ...e,
            stance: enr.stanceForce ?? 'enraged',
            ...(enr.attacksOverride ? { phaseAttacksOverride: enr.attacksOverride } : {}),
            ...(enr.aiPatternOverride ? { phaseAiPattern: enr.aiPatternOverride } : {}),
          }
        : e,
    ),
  }));
  return s;
}

/**
 * applyEnvironmentalPressure：累计所有存活 boss 的战场压力并扣减资源。
 * 在每回合 tick 处调用（applyPlayerAction 步骤 0b·紧随 staminaTickPerTurn）。
 * 多 boss 并存时线性叠加（oxygenDrainBonus / staminaTickBonus / sanityDamagePerTurn）。
 */
export function applyEnvironmentalPressure(state: GameState): GameState {
  if (state.phase.kind !== 'combat' || !state.run) return state;
  const combat = state.phase.combat;

  let oxygenDrain = 0;
  let staminaDrain = 0;
  let sanityDmg = 0;

  for (const e of combat.enemies) {
    if (e.hp <= 0) continue;
    const def = getEnemyDef(e.defId);
    if (!def?.environmentalPressure) continue;
    const ep = def.environmentalPressure;
    oxygenDrain += ep.oxygenDrainBonus ?? 0;
    staminaDrain += ep.staminaTickBonus ?? 0;
    sanityDmg += ep.sanityDamagePerTurn ?? 0;
  }

  if (oxygenDrain === 0 && staminaDrain === 0 && sanityDmg === 0) return state;

  let s = state;
  if (oxygenDrain > 0) {
    s = applyStatsDelta(s, { oxygen: -oxygenDrain });
    s = pushCombatLog(s, { actor: 'system', text: `它堵住了出口——氧气消耗加快（氧气 -${oxygenDrain}）。` });
  }
  if (staminaDrain > 0) {
    s = applyStatsDelta(s, { stamina: -staminaDrain });
    s = pushCombatLog(s, { actor: 'system', text: `战场压力让你消耗更快（体力 -${staminaDrain}）。` });
  }
  if (sanityDmg > 0) {
    s = applyStatsDelta(s, { sanity: -sanityDmg });
    s = pushCombatLog(s, { actor: 'system', text: `它的存在本身就在消磨你（理智 -${sanityDmg}）。` });
  }

  return s;
}

// ——— 新 boss 机制钩子 ———

/**
 * maybeEnemySplit（裂球·split-proliferation）：每 intervalTurns 回合检查一次，若目标在本检查周期内
 * 受到伤害 < minDamageToDeny → 分裂产生最多 spawnCount 只新个体（HP = spawnHpRatio × spawnDefId.hp），
 * 总 party 不超 maxPartySize。检查结束后重置 splitDamageAccum + 更新 splitLastCheckTurn。
 * 仅带 splitBehavior 的敌人进分支；普通敌人逐字节不变。
 */
export function maybeEnemySplit(state: GameState): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;
  const currentTurn = combat.turn;
  let s = state;

  for (const e of combat.enemies) {
    if (e.hp <= 0) continue;
    const def = getEnemyDef(e.defId);
    const sb = def?.splitBehavior;
    if (!sb) continue;

    const lastCheck = e.splitLastCheckTurn ?? 0;
    if (currentTurn - lastCheck < sb.intervalTurns) continue; // 未到检查点

    const damageAccum = e.splitDamageAccum ?? 0;
    const spawnDef = getEnemyDef(sb.spawnDefId);

    // 重置累计伤害 + 记录检查回合
    s = setCombat(s, (c) => ({
      ...c,
      enemies: c.enemies.map((x) =>
        x.instanceId === e.instanceId
          ? { ...x, splitDamageAccum: 0, splitLastCheckTurn: currentTurn }
          : x,
      ),
    }));

    if (damageAccum >= sb.minDamageToDeny) continue; // 受伤够多，不分裂

    const curPartySize = (s.phase.kind === 'combat' ? s.phase.combat.enemies : []).filter((x) => x.hp > 0).length;
    const slots = Math.max(0, sb.maxPartySize - curPartySize);
    if (slots <= 0 || !spawnDef) continue;

    const toSpawn = Math.min(sb.spawnCount, slots);
    const spawnHp = Math.max(1, Math.round(spawnDef.hp * sb.spawnHpRatio));
    const spawnName = spawnDef.name;
    const encId = s.phase.kind === 'combat' ? s.phase.combat.combatId : 'split';

    s = pushCombatLog(s, {
      actor: 'system',
      text: `${def.name} 崩开——裂成 ${toSpawn} 只更小的。`,
    });

    // 唯一性后缀＝状态内单调计数 spawnSeq（同毫秒多批次 spawn 用 Date.now() 必撞号·见 CombatState.spawnSeq）
    const seqStart = (s.phase.kind === 'combat' ? s.phase.combat.spawnSeq : undefined) ?? 0;
    const newInstances = Array.from({ length: toSpawn }, (_, i) => ({
      instanceId: `${encId}.split.${seqStart + i}`,
      defId: sb.spawnDefId,
      hp: spawnHp,
      stance: 'attacking' as const,
      aggro: spawnDef.threat,
      statuses: [],
      // 新分裂个体的检查周期从**它出生的回合**起算——不种则缺省 0＝「从开战起算」，出生即到期、
      // 下回合立刻再分裂（旧撞号 bug 曾把这条级联掩盖成「一击打多只」·见 CombatState.spawnSeq）。
      splitLastCheckTurn: currentTurn,
    }));

    s = setCombat(s, (c) => ({ ...c, enemies: [...c.enemies, ...newInstances], spawnSeq: seqStart + toSpawn }));
    s = pushCombatLog(s, { actor: 'system', text: `${toSpawn} 只${spawnName}出现在你周围。` });
  }

  return s;
}

/**
 * maybeCorpseEat（清道夫·corpse-eating）：killedInstanceId 所代表的敌人 HP ≤ 0 时，
 * party 内带 corpseEating 的敌人获得 HP 回复，并吸收 absorbsAttacksFrom 列出的 defId 的攻击。
 * 若 killedInstanceId 的敌人仍然存活（HP > 0），本函数为 no-op（守幂等）。
 */
export function maybeCorpseEat(state: GameState, killedInstanceId: string): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;

  const killed = combat.enemies.find((e) => e.instanceId === killedInstanceId);
  if (!killed || killed.hp > 0) return state; // 目标未死

  const killedDef = getEnemyDef(killed.defId);
  let s = state;

  for (const e of combat.enemies) {
    if (e.hp <= 0 || e.instanceId === killedInstanceId) continue;
    const def = getEnemyDef(e.defId);
    const ce = def?.corpseEating;
    if (!ce) continue;

    // HP 回复（不超过自身 def.hp 上限）
    const newHp = Math.min(def.hp, e.hp + ce.hpGainPerCorpse);
    s = setCombat(s, (c) => ({
      ...c,
      enemies: c.enemies.map((x) =>
        x.instanceId === e.instanceId ? { ...x, hp: newHp } : x,
      ),
    }));
    s = pushCombatLog(s, {
      actor: 'enemy',
      text: `${def.name} 扑上去吃掉了尸体——它恢复了 ${newHp - e.hp} 点生命。`,
    });

    // 吸收攻击（仅当死亡敌人的 defId 在 absorbsAttacksFrom 列表中）
    if (ce.absorbsAttacksFrom?.includes(killed.defId) && killedDef) {
      const newAttacks = killedDef.attacks.map((a) => ({
        ...a,
        id: `absorbed.${a.id}`, // 避免 id 冲突
      }));
      s = setCombat(s, (c) => ({
        ...c,
        enemies: c.enemies.map((x) =>
          x.instanceId === e.instanceId
            ? { ...x, absorbedAttacks: [...(x.absorbedAttacks ?? []), ...newAttacks] }
            : x,
        ),
      }));
      s = pushCombatLog(s, {
        actor: 'system',
        text: `${def.name} 消化了${killedDef.name}——它的本能变成了它自己的。`,
      });
    }
  }

  return s;
}

/**
 * maybeMetamorphosis（茧化居民·metamorphosis）：每回合检查带 metamorphosis 的敌人的阶段状态。
 * - larva + 玩家氧气 ≤ cocoonTriggerOxygen → 茧化（phaseArmorOverride=cocoonArmor，计时开始）。
 * - cocoon + hp 已在 applyAttack 降至 0 → 茧破（奖励掉落 + 成体复活）。
 * - cocoon + cocoonTurnsLeft 已由 maybeCocoonCountdown 清零 → 羽化成体。
 * 非 metamorphosis 敌人逐字节不变。
 */
export function maybeMetamorphosis(state: GameState): GameState {
  if (state.phase.kind !== 'combat' || !state.run) return state;
  const oxygen = state.run.stats.oxygen;
  let s = state;

  for (const e of (s.phase.kind === 'combat' ? s.phase.combat.enemies : [])) {
    const def = getEnemyDef(e.defId);
    const meta = def?.metamorphosis;
    if (!meta) continue;

    const stage = e.metamorphosisStage ?? 'larva';

    if (stage === 'larva' && oxygen <= meta.cocoonTriggerOxygen) {
      // 幼体→茧化
      s = setCombat(s, (c) => ({
        ...c,
        enemies: c.enemies.map((x) =>
          x.instanceId === e.instanceId
            ? { ...x, metamorphosisStage: 'cocoon', cocoonTurnsLeft: meta.cocoonMaxTurns, phaseArmorOverride: meta.cocoonArmor }
            : x,
        ),
      }));
      s = pushCombatLog(s, {
        actor: 'system',
        text: `${def.name} 开始包裹自己——它在缩紧，外壳变硬。`,
      });
    } else if (stage === 'cocoon' && e.hp <= 0) {
      // 茧被击破
      if (meta.cocoonBreakBonus && s.run) {
        const bonusLoot: InventoryItem[] = [];
        for (const bonus of meta.cocoonBreakBonus) {
          const qty = randRange(bonus.qty);
          if (qty > 0 && s.run) {
            s = { ...s, run: { ...s.run!, inventory: addToInventory(s.run.inventory, bonus.itemId, qty) } };
            bonusLoot.push({ itemId: bonus.itemId, qty });
          }
        }
        s = enqueuePickup(s, bonusLoot, '战利品');
      }
      if (meta.breakDestroys) {
        // 卵 / 易碎茧（breakDestroys·§9.5）：击破即**销毁**、不复活——标 stage='adult' 终态防 maybeMetamorphosis
        // 重入（hp 维持 0＝死亡·由既有 hp≤0 收尸路径处理）。「打掉即毁」＝「不打掉就孵化」的反面。
        s = setCombat(s, (c) => ({
          ...c,
          enemies: c.enemies.map((x) =>
            x.instanceId === e.instanceId
              ? { ...x, metamorphosisStage: 'adult' as const, cocoonTurnsLeft: undefined, phaseArmorOverride: undefined }
              : x,
          ),
        }));
        s = pushCombatLog(s, {
          actor: 'system',
          text: `${def.name}在孵化前被凿破——里面还没成形的东西散进了水里。`,
        });
      } else {
        // 成体复活（HP 恢复 adultHp·清除护甲覆盖·换攻击表）
        s = setCombat(s, (c) => ({
          ...c,
          enemies: c.enemies.map((x) =>
            x.instanceId === e.instanceId
              ? {
                  ...x,
                  hp: meta.adultHp,
                  metamorphosisStage: 'adult' as const,
                  cocoonTurnsLeft: undefined,
                  phaseArmorOverride: undefined,
                  phaseAttacksOverride: meta.adultAttacksOverride,
                  stance: 'attacking' as const,
                }
              : x,
          ),
        }));
        s = pushCombatLog(s, {
          actor: 'system',
          text: `茧壳从内部炸开——${def.name} 羽化出来，比原来快了三倍。`,
        });
      }
    } else if (stage === 'cocoon' && (e.cocoonTurnsLeft ?? 1) <= 0) {
      // 茧化计时归零→羽化成体（HP 满格·攻击表替换）
      s = setCombat(s, (c) => ({
        ...c,
        enemies: c.enemies.map((x) =>
          x.instanceId === e.instanceId
            ? {
                ...x,
                hp: meta.adultHp,
                metamorphosisStage: 'adult' as const,
                cocoonTurnsLeft: undefined,
                phaseArmorOverride: undefined,
                phaseAttacksOverride: meta.adultAttacksOverride,
                stance: 'attacking' as const,
              }
            : x,
        ),
      }));
      s = pushCombatLog(s, {
        actor: 'system',
        text: `茧化完成——${def.name} 撑破外壳，以全新的姿态出现。`,
      });
    }
  }

  return s;
}

/**
 * maybeCocoonCountdown（茧化居民·每轮末倒计时）：递减 cocoonTurnsLeft；到 0 时
 * 下一次 maybeMetamorphosis 将触发羽化。分离计时与转换逻辑，避免同回合双重判断。
 */
export function maybeCocoonCountdown(state: GameState): GameState {
  if (state.phase.kind !== 'combat') return state;
  return setCombat(state, (c) => ({
    ...c,
    enemies: c.enemies.map((e) => {
      if (e.metamorphosisStage !== 'cocoon' || e.cocoonTurnsLeft === undefined) return e;
      return { ...e, cocoonTurnsLeft: Math.max(0, e.cocoonTurnsLeft - 1) };
    }),
  }));
}

// ——— 口孵深鱼（maternalBehavior）钩子 ———

/**
 * maybeInterceptJuvenile（口孵深鱼·截击）：玩家攻击命中护巢仔时，母鱼以 interceptChance 概率
 * 跃出截击——伤害以 armorWhileProtected 减伤后转移到母鱼，护巢仔不受伤。
 *
 * 在 applyAttack 的装甲计算**之前**调用（rawDmg = pre-armor 命中强度）：
 *   - interceptChance ≥ 1 → rollChance 不掷骰（零 RNG 消耗·既有 baseline 逐字节不变）。
 *   - interceptChance < 1 → 掷一次骰（⚠️ 改变 RNG 流·需重新录 baseline·defer-number-tuning）。
 *
 * 返回 non-null = 截击已处理，applyAttack 应直接 return 此值；null = 未截击，继续正常流程。
 */
export function maybeInterceptJuvenile(
  state: GameState,
  target: EnemyInstance,
  rawDmg: number,
  damageType: string,
  attackName: string,
): GameState | null {
  if (state.phase.kind !== 'combat') return null;
  const combat = state.phase.combat;

  // 找带 maternalBehavior + shieldedBy 含此护巢仔 defId 的母鱼（存活）
  for (const e of combat.enemies) {
    if (e.hp <= 0) continue;
    const def = getEnemyDef(e.defId);
    const mb = def?.maternalBehavior;
    if (!mb) continue;
    if (!def.shieldedBy?.includes(target.defId)) continue;

    // interceptChance≥1 → rollChance 必触发且零 RNG；<1 → 掷一次骰
    if (!rollChance(mb.interceptChance)) return null;

    // 截击触发：母鱼以 armorWhileProtected 减伤（非双重减伤·raw dmg 尚未经护巢仔装甲）
    const interceptDmg = damageType === 'physical'
      ? Math.max(1, rawDmg - mb.armorWhileProtected)
      : rawDmg;

    let s = setCombat(state, (c) => ({
      ...c,
      enemies: c.enemies.map((x) =>
        x.instanceId === e.instanceId
          ? { ...x, hp: Math.max(0, x.hp - interceptDmg), aggro: x.aggro + Math.ceil(interceptDmg / 5) }
          : x,
      ),
    }));
    s = pushCombatLog(s, {
      actor: 'enemy',
      text: `${def.name} 冲到前面截下了这一击——${attackName}命中母鱼，造成 ${interceptDmg} 点伤害。`,
    });
    // boss 阶段检查（截击可能推过 HP 阈值）
    s = maybeBossPhaseShift(s, e.instanceId);
    return s;
  }

  return null; // 目标不是任何母鱼的护巢仔，或截击未触发
}

/**
 * maybeConsumeJuvenile（口孵深鱼·消耗护巢仔）：母鱼 HP < 50% 时，于敌方回合开头消耗一只存活护巢仔
 * 回血（consumeJuvenileHpGain，不超过 def.hp 上限）。per-turn 自然节流——每次调用至多消耗一只。
 * 消耗后立即调用 applyMaternalEnrageIfAlone（若是最后一只护巢仔则触发 enrage）。
 * 仅带 maternalBehavior 的敌人进分支；普通敌人逐字节不变。
 */
export function maybeConsumeJuvenile(state: GameState): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;
  let s = state;

  for (const e of combat.enemies) {
    if (e.hp <= 0) continue;
    const def = getEnemyDef(e.defId);
    const mb = def?.maternalBehavior;
    if (!mb) continue;

    // 触发条件：HP < 50%
    if (e.hp >= def.hp * 0.5) continue;

    // 找一只存活护巢仔
    const shieldedDefIds = def.shieldedBy ?? [];
    const juvenile = (s.phase.kind === 'combat' ? s.phase.combat.enemies : [])
      .find((x) => x.hp > 0 && shieldedDefIds.includes(x.defId));
    if (!juvenile) continue;

    const juvenileDef = getEnemyDef(juvenile.defId);
    const newMothHp = Math.min(def.hp, e.hp + mb.consumeJuvenileHpGain);
    const actualHeal = newMothHp - e.hp;

    // 护巢仔 HP→0（被母鱼吞回·非战斗击杀·不触发 corpseEating·不给玩家战利品）
    s = setCombat(s, (c) => ({
      ...c,
      enemies: c.enemies.map((x) =>
        x.instanceId === juvenile.instanceId ? { ...x, hp: 0 } : x,
      ),
    }));
    // 母鱼回血
    s = setCombat(s, (c) => ({
      ...c,
      enemies: c.enemies.map((x) =>
        x.instanceId === e.instanceId ? { ...x, hp: newMothHp } : x,
      ),
    }));
    s = pushCombatLog(s, {
      actor: 'enemy',
      text: `${def.name} 将一只${juvenileDef?.name ?? '护巢幼鱼'}重新噙入口中——它恢复了 ${actualHeal} 点生命。`,
    });
    // 护巢仔全灭检查（吞仔后可能触发 enrage）
    s = applyMaternalEnrageIfAlone(s);
  }

  return s;
}

/**
 * applyMaternalEnrageIfAlone（口孵深鱼·护巢仔全灭 enrage）：检查带 maternalBehavior 的母鱼，
 * 若 shieldedBy 列出的所有护巢仔均已死亡（hp ≤ 0）→ 写入 phaseAttacksOverride（enragedAttacks），
 * 切换 stance = 'enraged'。
 * 复用 BossPhase.attacksOverride 同款字段（enemyAttackPlayer 已读 phaseAttacksOverride·无额外改动）。
 * 幂等：已有 phaseAttacksOverride 的母鱼跳过（防重复触发）。非 maternalBehavior 敌人逐字节不变。
 */
export function applyMaternalEnrageIfAlone(state: GameState): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;
  let s = state;

  for (const e of combat.enemies) {
    if (e.hp <= 0) continue;
    if (e.phaseAttacksOverride) continue; // 已 enrage（幂等守卫）
    const def = getEnemyDef(e.defId);
    const mb = def?.maternalBehavior;
    if (!mb) continue;

    const shieldedDefIds = def.shieldedBy ?? [];
    if (shieldedDefIds.length === 0) continue;

    // 所有护巢仔均已不在（hp ≤ 0）？
    const anyAlive = (s.phase.kind === 'combat' ? s.phase.combat.enemies : [])
      .some((x) => x.hp > 0 && shieldedDefIds.includes(x.defId));
    if (anyAlive) continue;

    // 护巢仔全灭 → enrage
    s = setCombat(s, (c) => ({
      ...c,
      enemies: c.enemies.map((x) =>
        x.instanceId === e.instanceId
          ? { ...x, phaseAttacksOverride: mb.enragedAttacks, stance: 'enraged' as const }
          : x,
      ),
    }));
    s = pushCombatLog(s, {
      actor: 'enemy',
      text: `${def.name} 的护巢幼鱼全部消失了——它的身体突然膨胀，出击节律完全变了。`,
    });
  }

  return s;
}

/**
 * maybeSwarmQueenRelocate（The Warren 女王·蜂群 boss SPEC §9.1）：女王被打进暴露窗 → 巢把她「撤」走。
 * 触发：目标是女王（def.swarmRelocate）且**非背水一战**（combat.warrenLastStand !== true）且 HP 比例
 * ≤ exposureThreshold（含被一击/DoT 打穿到 ≤0——还有卵室可退时她永不死、只逃·§4）→ 推 relocateText、置 pendingSwarmRelocate。
 * applyPlayerAction 第 4a 步（**先于**胜负判定）据此走 finalizeSwarmRelocate（房间清空·女王逃脱·下一间满血重来）。
 * 幂等：已 pendingSwarmRelocate 跳过。背水一战（第三间卵室·roomsCleared>=2）恒 no-op ⇒ 女王可被打死＝取胜（§4）。
 * 非女王 def / 无 swarmRelocate ⇒ 逐字节不变（普通 boss 战不受影响）。
 */
export function maybeSwarmQueenRelocate(state: GameState, instanceId: string): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;
  if (combat.warrenLastStand) return state; // 背水一战禁撤（§4·状态不是地点）
  if (combat.pendingSwarmRelocate) return state; // 幂等
  const queen = combat.enemies.find((e) => e.instanceId === instanceId);
  if (!queen) return state;
  const def = getEnemyDef(queen.defId);
  const sr = def?.swarmRelocate;
  if (!sr) return state; // 非女王
  if (queen.hp > def.hp * sr.exposureThreshold) return state; // 未进暴露窗
  let s = pushCombatLog(state, { actor: 'system', text: sr.relocateText });
  s = setCombat(s, (c) => ({ ...c, pendingSwarmRelocate: true }));
  return s;
}

/**
 * maybeSwarmCollapse（The Warren 崩解·蜂群 boss SPEC §9.6）：女王死 → 取胜（§4）+ 残余崩解演出。
 * **仅背水一战落地**——还有卵室可退时女王在 hp≤threshold 即被 relocate 撤走、永不到 hp≤0（§4），故本函数
 * 用 warrenLastStand 收窄，杜绝「非背水一战 overkill 到 0 被误判为击杀」的窗（否则会抢在 relocate 前 finalizeVictory）。
 * 触发：死角里存在死亡的女王（def.swarmRelocate 且 hp≤0）→ 推 collapseText，把其余存活单位一并 hp→0 并记入
 * fledInstanceIds（无首失序·崩解不给战利品·§4「群本已所剩无几」）。女王死后 allEnemiesDefeated ⇒ 下一判定
 * finalizeVictory 自然收束＝取胜。幂等：无存活非女王残余时 no-op。非死角 / 非女王 ⇒ 逐字节不变。
 */
export function maybeSwarmCollapse(state: GameState): GameState {
  if (state.phase.kind !== 'combat') return state;
  const combat = state.phase.combat;
  if (!combat.warrenLastStand) return state; // 崩解只在背水一战落地（还有卵室可退时只逃不死·§4）
  const deadQueen = combat.enemies.find((e) => {
    const d = getEnemyDef(e.defId);
    return !!d?.swarmRelocate && e.hp <= 0;
  });
  if (!deadQueen) return state;
  const survivors = combat.enemies.filter((e) => e.hp > 0);
  if (survivors.length === 0) return state; // 已崩解（幂等）
  const def = getEnemyDef(deadQueen.defId);
  let s = pushCombatLog(state, {
    actor: 'system',
    text:
      def?.swarmRelocate?.collapseText ??
      '中心一死，巢群失去了所有秩序——它们开始互相撕咬，很快什么都不剩。',
  });
  s = setCombat(s, (c) => ({
    ...c,
    enemies: c.enemies.map((e) => (e.hp > 0 ? { ...e, hp: 0 } : e)),
    fledInstanceIds: [...(c.fledInstanceIds ?? []), ...survivors.map((e) => e.instanceId)],
  }));
  return s;
}

// ——— Puffer 自爆（The Warren·蜂群 boss SPEC §9.9）———

/**
 * pufferArmed（Puffer 自爆·武装门·SPEC §9.9）：带 selfDestruct 的单位当前是否「已武装」。
 * - 有 metamorphosis 的 def：仅 **adult** 态武装（larva/cocoon 期击破安全＝「趁茧别让它孵」·§5）。
 * - 无 metamorphosis 的 def：恒武装（从头就是炸弹的地雷类）。
 * 无 selfDestruct ⇒ false。全库通用（不写单敌分支）·非 Puffer 逐字节不变。
 */
export function pufferArmed(def: EnemyDef | undefined, e: EnemyInstance): boolean {
  if (!def?.selfDestruct) return false;
  if (def.metamorphosis) return e.metamorphosisStage === 'adult';
  return true;
}

/**
 * detonateSelfDestruct（Puffer 自爆·引爆·SPEC §9.9）：引爆一枚 **armed** Puffer——对玩家施体力
 * （+可选理智）AoE 伤、把该单位 hp→0、推 detonateText。战斗无位置 ⇒ AoE 落点＝玩家（SPEC 只述对玩家）。
 * 近战触发（combat.ts applyPlayerAttack 命中后）与到点触发（runEnemyTurn 该单位回合）共用本函数；
 * **远程豁免＝调用方不调本函数**（远程击破走普通死亡·不溅玩家）。
 * 幂等：目标不存在 / 已 hp≤0 / 无 selfDestruct / 未武装 ⇒ no-op。爆炸无视潜水服减伤（占位数值 defer）。
 */
export function detonateSelfDestruct(state: GameState, instanceId: string): GameState {
  if (state.phase.kind !== 'combat' || !state.run) return state;
  const e = state.phase.combat.enemies.find((x) => x.instanceId === instanceId);
  // 不 guard hp≤0：**被这一击近战打死也要炸**（SPEC §9.9「近战会吃爆」）。单发保证＝两处调用点各只调一次
  // （近战命中一次 / 到点回合一次·到点路径由 runEnemyTurn 的 hp>0 过滤保证不打死尸）·故无需二次幂等旗标。
  if (!e) return state;
  const def = getEnemyDef(e.defId);
  if (!pufferArmed(def, e)) return state;
  const sd = def!.selfDestruct!;
  let s = state;
  const stam = randRange(sd.staminaDamage);
  s = applyStatsDelta(s, { stamina: -stam });
  let msg = `${sd.detonateText}（体力 -${stam}）`;
  if (sd.sanityDamage) {
    const san = randRange(sd.sanityDamage);
    s = applyStatsDelta(s, { sanity: -san });
    msg += `（理智 -${san}）`;
  }
  s = pushCombatLog(s, { actor: 'system', text: msg });
  s = setCombat(s, (c) => ({
    ...c,
    enemies: c.enemies.map((x) => (x.instanceId === instanceId ? { ...x, hp: 0 } : x)),
  }));
  return s;
}

/**
 * maybePufferMeleeDetonate（Puffer 自爆·玩家攻击侧·§9.9）：玩家攻击命中 armed Puffer 后——**近战**命中 →
 * 当场引爆·溅玩家（含被这一击打死·detonateSelfDestruct）；**远程**命中不引爆＝「隔水拆除」豁免（远程击破仅走
 * 普通死亡·若这一击已打死且配 defusedText 给反馈）。近战 = requiresEquipment !== 'ranged'（刀/斧=tool·拳皆近战）。
 * 非 Puffer / 未武装 ⇒ no-op（applyAttack 命中后调用·target 阶段不因该击改变故 pufferArmed 判定稳）。
 */
export function maybePufferMeleeDetonate(state: GameState, isRanged: boolean, targetInstanceId: string): GameState {
  if (state.phase.kind !== 'combat') return state;
  const target = state.phase.combat.enemies.find((e) => e.instanceId === targetInstanceId);
  if (!target) return state;
  const def = getEnemyDef(target.defId);
  if (!pufferArmed(def, target)) return state;
  if (!isRanged) return detonateSelfDestruct(state, targetInstanceId);
  if (target.hp <= 0 && def?.selfDestruct?.defusedText) {
    return pushCombatLog(state, { actor: 'system', text: def.selfDestruct.defusedText });
  }
  return state;
}
