深海回响 · 下一个 session 交接

项目：深海回响（Blue·~/Desktop/Blue）——深海下潜 roguelike·港口↔下潜 meta-loop·材料经济元进度。起手定位跑 `npm run handoff`（git 再生·别手抄）。约定不复读（根 CLAUDE.md 自动入上下文）；持久 gotcha 见 docs/QUIRKS.md（尾号见文件·当前尾 #240）。

上个 session（2026-07-10·#283·Cowork 交互·Opus·收口/清理非新机制·regress 95/95·commit `cbe8dfe`·未推待 nightly·ahead 44）：**重量系统三改**（作者审重量系统后拍）。① dockyard `extraConsumableSlot`「+1格」死字段整条管线拔除（重量制 #159 后零 gameplay 消费）——设施本身保留做远海 POI 门（chart_pois `requiresLighthouseUpgrade`）；② 装备负重四档改**百分比制**：`equipment.ts` 新增 `LOADOUT_WEIGHT_CAP=20` 单源，`weightTier(weight, cap=…)` 按占比分档（≤40/70/100%），cap=20 逐字节等价旧 8/14/20/21 绝对阈值，未来提/降负重上限只改一个常量或传 cap；③ 上浮与重量**彻底解耦**（作者拍「复杂化不增游戏性」）——清 `types/items.ts` 那句「负重影响上浮速度/氧气」遗留注释，`ascent.ts::planAscent` 只按深度+氮气算回合。CHANGELOG #283 / QUIRK #240（四条易踩：上浮不读重量·档位%制·dockyard 空效果别删·两套重量互不相干）。详见 memory [[weight-systems]]。验证＝云端 tar 快照+`npm ci`+`ESBUILD_BINARY_PATH` 跑全 tsx（device 的 Linux VM 挂 macOS esbuild 跑不了 tsx）·95/95 绿。

═══ 本 session 待办（按序）═══

〔0·已澄清·勿再当待办〕**装备 SPEC「段2」三传感器线 stat 迁移＝早已实装并提交**（2026-07-10 Cowork 并发核实 git 真值·SPEC 状态头 stale 已纠·见 [[weight-systems]]）：sonar/light/suit stat 已在各件 `upgradeSteps`·`getRunBonuses` 已读 `getEquipmentStats`·`upgrades.json` 仅剩 salvage_guild+tankhouse·双计已收（#140/#142）。**无 SAVE 迁移＝正确**（#99 未发布不写迁移·旧 `upgrade.sonar.*` 无 def 静默跳过·别再想 hydrate 折算老档·那与 #99 冲突）。仅留白：装备 `level` 恒=1、charm2/3 槽（二章·D 项）+ 占位数值统一调（defer）。**上一版交接曾把它当「大待办 + 写 SAVE 迁移」＝错·别照做。**

〔1·大·需作者在场·Mac·live〕The Warren 数值/手感 tuning + 手感验收（Opus·medium·别无人值守调）：机制骨架已全实装（#269–#276），只差作者一次性调数值 + 逐拍死角终局手感（`defer-number-tuning`）。要调：女王/Spawn/Warden/Puffer/Egg HP·`WARREN_DENSITY_BY_HOPS`·`WARREN_EGGS_PER_CHAMBER`·`swarmRelocate.exposureThreshold`×`warrenScreen.shieldCount`×繁殖储备一起调〔跑步机风险·§15.2/§15.8〕·三卵室深度档·zone.warren/poi owner+门控（现全占位）。做前读：蜂群boss SPEC §10/§15.8/§17 + quirk #238/#239。顺带手感验收（结转·作者 Mac live）：感知门两态+声呐门+§5.1 空屏；Mira→Sela 引荐/信任/Corin 测绘；战斗 UI 手机断点；对话选项面板收窄；下潜/海图面板按钮不溢框。

〔2·大·需作者在场·作者已在动〕Ch2 gameplay（禁岛·髓织虫线）（Opus·high）：canon 就位 + 作者在写 `深海回响_禁岛_设计讨论稿.md`（起手读它 + `深海回响_祭祀文明_SPEC.md` + 蜂群boss §16 + 剧情 §4.2/§3.7 + `ancient-civilization-cephalopod` memory）。作者 beat：进岛见「尸体」→反常不腐（B 省能静止 tell）→破坏尸体＝就地开战（较有利）/不破坏→深区尸体尽活→更不利围攻。待拍：B 女王是否 mini-boss；「美化版→真相」双文本怎么落（§3.7 模板）；与 §4.2 4 潜点/邪神幻觉叠。守揭示锁章（Ch2 只到现象+人祸·神=古文明=高科技锁三章）。**Ch2 空堡垒缸/Voss 168/宠物阶段甲乙丙 归此批·待科考站 zone 建**。

〔3·内容·部分可 Ch1 无人值守〕Voss 头足目系列续（全设计 `docs/spec/深海回响_观察手记_档案系列.md`·改先读）：① 档案 147/156/163 录音 + 三发现幕 + Aldo/Otto 问询链＝全 Ch1 实装（#278/#279/#280），**只剩作者过声线**（评审稿已给）。② 168（科考站）+ 宠物阶段甲乙丙 + 堡垒缸 + 窝祭坛 + 寂寞彩蛋 归 Ch2（待 zone 建·随〔2〕）。守：录音硬锁生物学层·不碰灵力/水鬼/失联真相；母亲整册只 147 用一次；编号非连号；发现地与录音内容脱钩。

〔4·方向·可选·需作者拍〕Phase 4 信任 retrofit（Aldo/Mira/Otto 接 `npcTrustTier`）；St3（图鉴/录音三件套）+ St4（氮醉内容潮）。Opus·high。

备忘

* 主角语调＝`protagonist-voice` memory「玩家投影·三条硬禁」（剧情 SPEC §2 已对齐）；写主角 POV 先过这条 + quirk #184 禁词门。NPC 台词被 check-protagonist-voice / check-draft-leak 豁免（npcs 目录）。
* 人名不音译（`no-transliteration-names`）。占位数值全 defer（`defer-number-tuning`）。「规则怪谈」作者自己提。上浮与重量解耦已定（[[weight-systems]]·别再提「负重影响上浮」）。
* NPC 进度对话＝`npc-progression-dialog` memory（visibleIf 复用事件 Condition·退场 onEnter setFlag+notHasFlag·守 playthrough-story §4b/c/d/e）。gate lore-collected 用「read outcome setProfileFlags + hasFlag」惯例·别新增原语。
* **regress 两条路**：① device 上 tsx 跑不了（挂载 node_modules 是 macOS esbuild）——只能 typecheck+纯 node check-* 门；② 全量＝云端 tar 快照（排 node_modules/.git·放 gitignored dist/ 再 device_stage_files）→ 云端 `npm ci`（Linux 原生 esbuild）→ `ESBUILD_BINARY_PATH=$(pwd)/node_modules/tsx/node_modules/@esbuild/linux-x64/bin/esbuild npm run regress -- --skip build`（36s·95/95·含全 tsx playthrough）·build 缺 rollup-linux 留 nightly（#147）。见 [[blue_regress_sandbox]]。
* **device 提交**：`git commit --only -- <显式文件>` 隔离作者并发 WIP·`--no-optional-locks`·`-F` CJK 消息·stale lock `mv .git/**/*.lock .git/.sandbox-junk/`（mount 不能 unlink·warning 无害·commit 照落）·见 [[sandbox_git_commit]]。fetch/push 沙箱 403（无凭证）·commit 留 nightly。

〔B·冻结·作者主导·别自己碰〕mimic（安康鱼假信标）+ 水鬼 apex：地基原样留（`playthrough-mimic` 绿）。`horror_sapien_*` 改名残留（quirk #233）随 B 一起做别单独碰。

树状态：main（HEAD `cbe8dfe` #283）· ahead 44 待 nightly 推（沙箱 403 不 push）· auto/weekend 无待合并 · **作者并发 live WIP 在树（`combat.ts`/`nitrogen.ts`/`物品栏与装备_SPEC.md` 未提交·别碰别 add；本 session 已 --only 隔离）** · fuse 垃圾 `docs/.fuse_hidden…`（mv 不掉·无害）· 遗留 `dist/blue-snap.tgz`（本 session 云端 regress 快照·gitignored·可删）· 定时任务全停。下一个 CHANGELOG #284 / quirk #241。
